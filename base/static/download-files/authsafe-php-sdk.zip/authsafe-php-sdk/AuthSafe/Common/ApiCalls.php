<?php
/**
 * AuthSafe API Calls Class of App
 *
 */
namespace AuthSafe\Common;

/**
 * Class ApiCalls
 *
 * @package ApiCalls
 */
class ApiCalls
{

    private $property_id;
    private $property_secret;
    private $apiURL;
    
    function __construct($property_id,$property_secret,$app_url)
    {
        $this->property_id = $property_id;
        $this->property_secret = $property_secret;
        $this->apiURL = $app_url;
    }

    private function getAPIUrl($path)
    {
        return $this->apiURL.$path;
    }

    public function callAPI($method, $url, $data){
        
        $url = $this->getAPIUrl($url);
        $curl = curl_init();

        switch ($method){
            case "POST":
                curl_setopt($curl, CURLOPT_POST, true);
                // var_dump($data);
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);                              
                break;
            default:
                if ($data)
                $url = sprintf("%s?%s", $url, http_build_query($data));
        }

        // OPTIONS:
        @curl_setopt($curl, CURLOPT_URL, $url);
        @curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'PROPERTYID: '.$this->property_id,
            'PROPERTYSECRET: '.$this->property_secret,
            "Cookie: sess_id=".$_COOKIE['sess_id'],
            //'Content-Type: application/json',
        ));
        @curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        @curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        // EXECUTE:

        $result = @curl_exec($curl);
        //if(!$result){die("Connection Failure");}

        /*var_dump($result);
        die();*/


        curl_close($curl);
        return $result;
    }

}