<?php
/**
 * AuthSafe Main Class of App
 *
 */
namespace AuthSafe\Login;

use AuthSafe\Common\ApiCalls;
/**
 * Class Login
 *
 * @package Login
 */
class LoginLogs
{

    private $objAPI;
    
    function __construct($objAPI)
    {
        $this->objAPI = $objAPI;

        // var_dump($this->objAPI);
        // die();
    }

    public function loginAttemptLog($logintype,$status,$userId = NULL,$email = NULL)
    {


        $method = "POST";
        $url = '/login-attempt';
        $data = array(
            'status' => $status,
            'email' => $email,
            'userId' => $userId,
            'logintype' => $logintype
        );

        return $this->objAPI->callAPI($method, $url, $data);
    }

    public function resetLog($status,$userId = NULL,$email = NULL)
    {
        $method = "POST";
        $url = '/password/reset';
        $data = array(
            'status' => $status,
            'email' => $email,
            'userId' => $userId
        );
        return $this->objAPI->callAPI($method, $url, $data);
    }

}