<?php
/**
 *  AuthSafe Main Class of App
 *
 */

namespace AuthSafe;

use AuthSafe\Login\LoginLogs;
use AuthSafe\Common\ApiCalls;
use AuthSafe\Common\ErrorMessage;


/**
 * Class AuthSafe
 *
 * @package AuthSafe
 */
class AuthSafe
{
    /**
     * @const string Version number of the AuthSafe PHP SDK.
     */
    const VERSION = '1.1.0';

    /**
     * @const string The name of the environment variable that contains the app ID.
     */
    const APP_ID_ENV_NAME = 'AUTHSAFE_APP_ID';

    /**
     * @const string The name of the environment variable that contains the app secret.
     */
    const APP_SECRET_ENV_NAME = 'AUTHSAFE_APP_SECRET';

    /**
     * @const string The name of the environment variable that contains the app secret.
     */
    //const APP_API_URL = 'http://localhost/app/authsafepix';

    /**
     * @var AuthSafeApp The AuthSafeApp entity.
     */
    protected $app;

    /**
     * Instantiates a new AuthSafe super-class object.
     *
     * @param array $config
     *
     * @throws AuthSafeSDKException
     */
    public $loginLog;
    public $objAPI;
    public $apiUrl;


    public function __construct(array $config = [])
    {
        $msg = array();
        $a = new ErrorMessage();
        if ((ENVIRONMENT=='development')) {
            $this->apiUrl = 'http://localhost/app/authsafepix';
        } else {
            $this->apiUrl = 'http://95.216.170.200:1337/authsafepix';
        }
        $config = array_merge([
            'property_id' => getenv(static::APP_ID_ENV_NAME),
            'property_secret' => getenv(static::APP_SECRET_ENV_NAME),
            'api_url' => $this->apiUrl
        ], $config);
        $this->objAPI = new ApiCalls($config['property_id'],$config['property_secret'],$config['api_url']);
        $this->loginLog = new LoginLogs($this->objAPI);

        if(empty($config['property_id']) || !isset($config['property_id']))
        {
            $msg['status'] = "error";
            $erno = 0;
            $msg['message'] = $a->errormsg($erno);
            // var_dump($msg);
            return $msg;
        }

        if(empty($config['property_secret']) || !isset($config['property_secret']))
        {
            $msg['status'] = "error";
            $erno = 0;
            $msg['message'] = $a->errormsg($erno);
            // var_dump($msg);
            return $msg;
        }

    }

    public function loginAttempt($logintype,$status,$userId = NULL,$email = NULL)
    {
        $b = new ErrorMessage();

        if(($status == 'success') &&(empty($email) || !isset($email)))
        {
            $msg['status'] = "error";
            $erno = 1;
            $msg['message'] = $b->errormsg($erno);
            // var_dump($msg);
            return $msg;
        }
        if(($status == 'success') &&(empty($userId) || !isset($userId)))
        {
            $msg['status'] = "error";
            $erno = 1;
            $msg['message'] = $b->errormsg($erno);
            // var_dump($msg);
            return $msg;
        }
        if(empty($status) || !isset($status))
        {
            $msg['status'] = "error";
            $erno = 1;
            $msg['message'] = $b->errormsg($erno);
            // var_dump($msg);
            return $msg;
        }
        if(empty($logintype) || !isset($logintype))
        {
            $msg['status'] = "error";
            $erno = 1;
            $msg['message'] = $b->errormsg($erno);
            // var_dump($msg);
            return $msg;
        }


        return $this->loginLog->loginAttemptLog($logintype,$status,$userId,$email);
    }

     public function passwordReset($status,$userId = NULL,$email = NULL)
    {
        $b = new ErrorMessage();

        if(empty($email) || !isset($email))
        {
            $msg['status'] = "error";
            $erno = 1;
            $msg['message'] = $b->errormsg($erno);
            // var_dump($msg);
            return $msg;
        }
        if(empty($userId) || !isset($userId))
        {
            $msg['status'] = "error";
            $erno = 1;
            $msg['message'] = $b->errormsg($erno);
            // var_dump($msg);
            return $msg;
        }
        if(empty($status) || !isset($status))
        {
            $msg['status'] = "error";
            $erno = 1;
            $msg['message'] = $b->errormsg($erno);
            // var_dump($msg);
            return $msg;
        }

        return $this->loginLog->resetLog($status,$userId,$email);

    }
}