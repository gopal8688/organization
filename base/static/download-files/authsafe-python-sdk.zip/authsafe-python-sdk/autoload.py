import os

def sqlAutoloadRegister(class_):
    prefix = 'AuthSafe\\'
    len_ = len(prefix)
    base_dir = os.getcwd()
    
    if (class_[:len_] != prefix[:len_]):
        return False
    
    