from Login.LoginLogs import LoginLogs
from flask import request
import Common.ApiCalls import ApiCalls
import Common.ErrorMessages import ErrorMessages

global VERSION, APP_ID_ENV_NAME, APP_SECRET_ENV_NAME, SERVER_NAME

class AuthSafe():
    def __init__(self):
        self.api_url = ''
        self.error_messages_obj = ErrorMessages()
        
        if SERVER_NAME == 'Flask':
            self.client_addr = request.remote_addr
            self.user_headers = request.headers
        if SERVER_NAME == 'Django':
            pass
        
        config = {
            'property_id': APP_ID_ENV_NAME,
            'property_secret': APP_SECRET_ENV_NAME,
            'api_url': self.api_url
        }
        self.api_obj = ApiCalls(config)
        self.loginlogs = LoginLogs(self.api_obj)
        
        if not config['property_id'] or not config['property_secret']:
            msg = {
                'status': 'error',
                'message': 'Authorization Error',
            }
            return msg
        
    def getLoginAttempts(self, login_type, status, user_id, email):
        if not status:
            msg = {
                'status': 'error',
                'message': 'Missing Parameter',
            }
            return msg
        
        url = self.login_url
        method = "POST"
        data = {
            'status': status,
            'email':, email,
            'userid':, user_id,
            'logintype': login_type,
            'cheaders': {
                'ip': self.client_addr,
                'headers': self.user_headers,
            }
        }
        
        return self.api_obj.callAPI(methods, url, data)
    
    def getPWDResetAttempts(self, status, user_id, email):
        if not status:
            msg = {
                'status': 'error',
                'message': 'Missing Parameter',
            }
            return msg
        
        method = "POST"
        url = self.pwd_url
        data = {
            'status': status,
            'email':, email,
            'userid':, user_id,
            'cheaders': {
                'ip': self.client_addr,
                'headers': self.user_headers,
            }
        }
        
        return self.api_obj.callAPI(methods, url, data)