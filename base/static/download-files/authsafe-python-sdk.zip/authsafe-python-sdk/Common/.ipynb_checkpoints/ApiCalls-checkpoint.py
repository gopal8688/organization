import os
import requests

class APICalls():
    def __init__(self, property_id, property_secret, app_url):
        self.property_id = property_id
        self.property_secret = property_secret
        self.app_url = app_url
        
    def __getAPIUrl(self, url):
        return os.path.join(self.app_url, url)
    
    def callAPI(self, method, url, data):
        cookie_dict = requests.Session().get_dict()
        
        url = self.__getAPIUrl(url)
        headers = {
            'Property_ID': self.property_id,
            'Property_Secret': self.property_secret,
            "Cookie: sess_id=": cookie_dict.get('session', ''),
        }
        
        if method == 'POST':
            r = requests.post(self.app_url, data=data, headers=headers)
        elif method == "PUT":
            r = requests.put(self.app_url, data=data, headers=headers)
        
        return r